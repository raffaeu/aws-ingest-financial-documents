const AWS = require('aws-sdk');
const Textract = new AWS.Textract();

exports.handler = async (event, context, callback) => {
    // Loop through the list of records in the event
    for (const record of event.Records) {

        // Get the message body
        const messageBody = JSON.parse(record.body);
        let extractions = [];

        // loop the records because we might receive
        // more than one
        for (let index = 0; index < messageBody.Records.length; index++) {
            // get the file attributes from S3
            const document = messageBody.Records[index];
            // if the operation was a put
            if (document.eventName === 'ObjectCreated:Put') {
                // get the file attributes                
                const key = decodeURIComponent(document.s3.object.key.replace(/\+/g, " "));                
                // extract text
                const extraction = await Textract.startDocumentTextDetection({
                    DocumentLocation: {
                        //Bytes: document.s3.object.size,
                        S3Object: {
                            Bucket: document.s3.bucket.name,
                            Name: key
                        }    
                    },
                    NotificationChannel: {
                        RoleArn: process.env.ROLE_ARN,
                        SNSTopicArn: process.env.TOPIC_ARN
                    }
                }).promise();       
                extractions.push({JobId: extraction.JobId, Document: key});                      
            }
        }
        // log
        console.log(`Analised the following documents: ${extractions}`);
        
        //complete
        callback(null, {
            statusCode: '200',
            body: JSON.stringify({'jobs': extractions})
        });
    }
};