const AWS = require('aws-sdk');
const Textract = new AWS.Textract();
const Dynamo = new AWS.DynamoDB();
const Comprehend = new AWS.Comprehend();

exports.handler = async (event, context, callback) => {
    // Loop through the list of records in the event
    for (const record of event.Records) {

        // Get the message body
        let message = JSON.parse(record.Sns.Message);
        console.log(record.Sns.Message);

        // retrieve the detection
        const detection = await Textract.getDocumentTextDetection({
            JobId: message.JobId
        }).promise();

        // build the text
        const text = detection.Blocks
            .map((block) => {
                if (block.BlockType === 'LINE' && block.Text && block.Text.length > 0) {
                    return block.Text;
                }
            })
            .join('\r\n');

        // detect language
        const language = await Comprehend.detectDominantLanguage({
            Text: text,
        }).promise();

        // detect entities
        const entities = await Comprehend.detectEntities({
            Text: text,
            LanguageCode: language.Languages[0].LanguageCode
        }).promise();

        // store in dynamo
        const putResult = await Dynamo.putItem({
            TableName: process.env.TABLE_NAME,
            Item: {
                id: { "S": context.awsRequestId },
                file: { "S": message.DocumentLocation.S3ObjectName },
                content: { "S": text },
                languages: { "L": language.Languages.map(l => ({ "S": l.LanguageCode })) },
                entities: { "L": entities.Entities.map(e => ({ "M": { type: { "S": e.Type }, text: { "S": e.Text } } })) }
            }
        }).promise();

        // log
        console.log(putResult);
    }

    //complete
    callback(null, {
        statusCode: '200',
        body: JSON.stringify({ 'status': 'classified' })
    });
};